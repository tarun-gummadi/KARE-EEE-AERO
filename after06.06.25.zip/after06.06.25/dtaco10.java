//create two linked list and compare it and print common elements
import java.util.*;
public class dtaco10 {
    public static void main(String[] args) {
        LinkedList<String> list1 = new LinkedList<String>();
        LinkedList<String> list2 = new LinkedList<String>();

        list1.add("John");
        list1.add("Peter");
        list1.add("Lucy");
        list1.add("Johnson");
        list1.add("Sajetha");
        list1.add("Keerthy");

        list2.add("John");
        list2.add("Johnson");
        list2.add("Sajetha");
        list2.add("Keerthy");
        list2.add("Kanish");
        list2.add("Padmini");
        list2.add("Muthumari");

        System.out.println("List 1: " + list1);
        System.out.println("List 2: " + list2);

        LinkedList<String> common = new LinkedList<String>();

        for (String item : list1) {
            if (list2.contains(item)) {
                common.add(item);
            }
        }

        System.out.println("Common elements: " + common);
    }
}
