//string buffering
import java.util.*;
public class str6{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuffer so = new StringBuffer("Hello");
        so.append(" World");//to add something at end of any string
        System.out.println(so);
        System.out.println("after append");
        System.out.println(so.capacity());
        so.insert(5, " Everyone");//to insert at specific place
        System.out.println(so);
        System.out.println("after insert");
        System.out.println(so.capacity());
        so.delete(4, 6);//to delete somepart of string
        System.out.println(so);
        System.out.println("after delete");
        System.out.println(so.capacity());
        so.replace(5, 6, " Padmini");//to replace a specific part
        System.out.println(so);
        System.out.println("after replace");
        System.out.println(so.capacity());
        so.reverse();//to reverse the string
        System.out.println(so);
        System.out.println("after reverse");
        System.out.println(so.capacity());
        so.delete(4, 6);//to delete a certain part
        System.out.println(so);
        System.out.println("after delete");
        System.out.println(so.capacity());
        sc.close();
    }
}