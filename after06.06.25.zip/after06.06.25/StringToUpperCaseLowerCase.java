//string to upper case using ASCII values
//lower to upper (ascii-32)
//upper to lower (ascii+32)
import java.util.*;
public class StringToUpperCaseLowerCase {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String");
        String str1 = sc.nextLine();
        String res ="";
        for(int i = 0;i<str1.length();i++){
            if(str1.charAt(i)>='a' && str1.charAt(i)<='z'){//to convert to lower case put 'A' and 'Z'
                res+=(char)((int)str1.charAt(i)-32);//to convert to lower case put +32
            }else{
                res+=str1.charAt(i);
            }
        }System.out.println(res);
        sc.close();
    }
}