//selection sort
import java.util.Scanner;
public class selectionsort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements to add in the array");
        int n = sc.nextInt();
        int[] arr21 = new int[n];
        for(int i = 0;i<n;i++){
            System.out.println("Enter the value for "+i);
            arr21[i]= sc.nextInt();
        }
        for(int i = 0;i<arr21.length-1;i++){
            int hold = i;
            for(int j = i+1;j<arr21.length;j++){
                if(arr21[hold]>arr21[j]){
                    hold = j;
                }
            }
            int temp =arr21[hold];
            arr21[hold]=arr21[i];
            arr21[i]=temp;
        }
        System.out.println("Sorted Array");
        for(int i = 0;i<n;i++){
            System.out.print(arr21[i]+" ");
        }
        sc.close();  
    }
}