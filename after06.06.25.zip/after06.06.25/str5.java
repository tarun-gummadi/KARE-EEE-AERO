//Write a program to find out the string is palindrome or not without using string functions
import java.util.*;
public class str5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String: ");
        String str1 = sc.nextLine();
        String str2 ="";
        for(int i=str1.length()-1;i>=0;i--){
            str2+=str1.charAt(i);
        }
        System.out.print(str2);
        int count = 0;
        for(int i=0;i<str1.length();i++){
            if(str1.charAt(i)==str2.charAt(i)){
                count++;
            }
        }
    if(count==str1.length()){
        System.out.println(" is a palindrome");
    }
    else{
        System.out.println(" is not a palindrome");
    }sc.close();
    }   
}