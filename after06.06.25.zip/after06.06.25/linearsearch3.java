//linear Search by giving array and checking the 16,38 sequence in it
public class linearsearch3 {
    public static void main(String[] args) {
        int[] a1 = {2,5,8,12,16,38,23,56,72,91};
        int[] key = {16,38} ;
        LinearSearch se = new LinearSearch();
        se.linearSearch(a1,key);
    } 
}
class LinearSearch{
    public void linearSearch(int[] a1,int[] key){
        for(int i = 0;i<a1.length-1;i++){
                if(a1[i]==key[0] && a1[i+1]==key[1]){
                    System.out.println(" ");
                    System.out.print("Found at index of "+i+" and "+(i+1));
                    break;
                }
        }
    }
}
/*
 * public class linearsearch3 {
    public static void main(String[] args) {
        int[] a1 = {2,5,8,12,16,38,23,56,72,91};
        int key = 16 ;
        int key2 = 38;
        LinearSearch se = new LinearSearch();
        se.linearSearch(a1,key,key2);
    } 
}
class LinearSearch{
    public void linearSearch(int[] a1,int key,int key2){
        for(int i = 0;i<a1.length-1;i++){
                if(a1[i]==key && a1[i+1]==key2){
                    System.out.println(" ");
                    System.out.print("Found at index of "+i+" and "+(i+1));
                    break;
                }
        }
    }
}
 */