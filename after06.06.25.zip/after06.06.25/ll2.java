//Single linked list to insert a new node at a position and insert a new node at start.
/*public class ll2{
    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.display(); // Output: 10 -> 20 -> 30 -> null
        list.insertatpos(4, 3);
        list.display();
        list.insertionatstart(4);
        list.display();
    }
}
class Node {
    int data;
    Node next;
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}
class LinkedList {
    Node head;
    //insert at end
    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }
    //insert at position
    public void insertatpos(int data,int n){
        Node newNode = new Node(data);
        Node temp=head;
        int i=0;
        while(temp!=null&& i<n-1){
            temp=temp.next;
            i++;
        }
        newNode.next=temp.next;
        temp.next=newNode;
    }
    //insert at start
    public void insertionatstart(int data){
        Node newNode = new Node(data);
        newNode.next=head;
        head=newNode;
    }
    //display
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
}*/