//magic square using multi dimensional array
import java.util.Scanner;
public class mgsquare {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the dimension ");
        int n = sc.nextInt();
        int[][] arr23 = new int[n][n];
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                System.out.println("Enter the value at position (" + i + "," + j + "): ");
                arr23[i][j] = sc.nextInt();
            }
        }
        System.out.println("The Matrix you entered:");
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                System.out.print(arr23[i][j] + " ");
            }
            System.out.println();
        }
        MagicSquare ms = new MagicSquare();
        ms.msquare(arr23, n);
        sc.close();
    }
}

class MagicSquare {
    public void msquare(int[][] arr23, int n) {
        int sum1 = 0;
        int sum2 = 0;
        for (int i = 0; i < n; i++) {
            sum1 += arr23[i][i];
            sum2 += arr23[i][n-i-1];
        }
        if (sum1 != sum2) {
            System.out.println("Not a Magic Square");
            return;
        }
        for (int k = 0; k<n; k++) {
            int sumr = 0;
            int sumc = 0;
            for (int j = 0; j<n; j++) {
                sumr += arr23[k][j];
                sumc += arr23[j][k];
            }
            if (sumr != sum1 || sumc != sum1) {
                System.out.println("Not a Magic Square");
                return;
            }
        }

        System.out.println("It is a Magic Square! with a sum of "+sum1);
    }
}
