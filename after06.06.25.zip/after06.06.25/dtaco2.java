//data collections Linked list
import java.util.*;
public class dtaco2 {
    public static void main(String[] args) {
        LinkedList<String> al = new LinkedList<String>();
        al.add("Lucy");
        al.add("Peter");
        al.add("Lucy");
        al.add("John");
        al.remove("Lucy");
        //al.delete; //these functionality doesn't works here
        //al.insert(2,"hi"); //these functionality doesn't works here
        //al.replace("",""); //these functionality doesn't works here
        Iterator<String> itr = al.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
    }
}
