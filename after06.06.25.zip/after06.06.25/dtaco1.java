//data collections array list topic
import java.util.*;
public class dtaco1 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        list.add("John");
        list.add("Peter");
        list.add("Lucy");
        list.add("Johnson");
        Iterator<String> itr = list.iterator();
        while (itr.hasNext()) {
            System.out.println(itr.next());     
        }
    }   
}