//program to represent atm transaction and otp generation
import java.util.Scanner;
public class atmproj {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to AGP Bank...");
        System.out.println("Please insert your card..");
        System.out.println("Thanks for inserting the card..");
        System.out.println("Wait until your card is scanned..");
        System.out.println("Do you need receipt for your transaction..");
        System.out.println("Enter Yes or No...");
        String input = sc.nextLine();
        if(input == "Yes" || input == "yes"){
            System.out.println("Thank you for Confirming..");
        }else if(input == "No" || input == "no"){
            System.out.println("Thank you for Confirming..");
        }
        System.out.println("Do not remove your card until the transaction complete...");
        int[] digit1 = new int[4];
        int[] digit2 = new int[4];
        int[] digit3 = new int[4];
        int[] digit4 = new int[4];
        System.out.println("Enter the 16 digits on your card");
        for(int i = 0;i<4;i++){
            System.out.println("Enter the"+" "+(i+1)+" digit in first set:"+" ");
            digit1[i]= sc.nextInt();
        }
        for(int i = 0;i<4;i++){
            System.out.println("Enter the"+" "+(i+1)+" digit in second set:"+" ");
            digit2[i]= sc.nextInt();
        }
        for(int i = 0;i<4;i++){
            System.out.println("Enter the"+" "+(i+1)+" digit in third set:"+" ");
            digit3[i]= sc.nextInt();
        }
        for(int i = 0;i<4;i++){
            System.out.println("Enter the"+" "+(i+1)+" digit in fourth set:"+" ");
            digit4[i]= sc.nextInt();
        }
        System.out.println("These are the values you entered:");
        for(int i=0;i<4;i++){
            System.out.print(digit1[i]);   
        }System.out.print(" ");
        for(int i=0;i<4;i++){
            System.out.print(digit2[i]);
        }System.out.print(" ");
        for(int i =0;i<4;i++){
            System.out.print(digit3[i]);
        }System.out.print(" ");
        for(int i=0;i<4;i++){
            System.out.print(digit4[i]);
        }System.out.print(" ");
        int even1 = 0;
        for(int i = 0;i<digit1.length;i++){
            if(digit1[i]!=0 && digit1[i]%2==0){
                even1++;
            }
        }
        int odd1 = 0;
        for(int i = 0;i<digit1.length;i++){
            if(digit2[i]!=0 && digit2[i]%2!=0){
                odd1++;
            }
        }
        int even2 = 0;
        for(int i = 0;i<digit1.length;i++){
            if(digit3[i]!=0 && digit3[i]%2==0){
                even2++;
            }
        }
        int odd2 = 0;
        for(int i = 0;i<digit1.length;i++){
            if(digit4[i]!=0 && digit4[i]%2!=0){
                odd2++;
            }
        }
        System.out.println();
        System.out.println("The OTP is:"+even1+odd1+even2+odd2);
        Savingsaccount sa = new Savingsaccount();
        Bankaccount ba = new Bankaccount();
        System.out.println("Enter 1 for deposition and 0 for withdrawal");
        int num = sc.nextInt();
        if(num == 0){
            System.out.println("Enter your balance amount:");
            int balance = sc.nextInt();
            System.out.println("Enter the amount you wanna withdraw::");
            int withdraws = sc.nextInt();
            if (balance>withdraws && balance-withdraws>=100){
                System.out.println("Your withdrawal in progress...");
                sa.withdraw();
                System.out.println("Your current balance is:"+(balance-withdraws));
            }else if(withdraws==balance){
                System.out.println("You need to keep 100 rs as balance in account");
            }else if(withdraws>balance){
                System.out.println("Not enough balance");
            }
            }else if(num == 1){
                System.out.println("Welcome for deposition");
                ba.deposit();
            }else{
                    System.out.println("Invalid input");
            }sc.close();
        }
    }
class Bankaccount{
    public void deposit(){
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("Enter your balance amount:");
            int balance = sc.nextInt();
            System.out.println("Enter the amount you wanna deposit:");
            int deposition = sc.nextInt();
            int amount = (balance+deposition);
            System.out.println("Deposited Successfully");
            System.out.println("Total account balance is"+" "+amount);
        }
    }
    public void withdraw(){
        System.out.println("Welcome to your withdrawal");
    }
}
class Savingsaccount extends atmproj{
    public void withdraw(){
        System.out.println("Your Withdrawal is ready");
        System.out.println("Transaction is completed");
    }
}