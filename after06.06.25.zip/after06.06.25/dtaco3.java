//data collections vector
import java.util.*;
public class dtaco3 {
    public static void main(String[] args) {
        Vector<String> al = new Vector<String>();
        al.add("Lucy");
        al.add("Peter");
        al.add("Lucy");
        al.add("John");
        al.remove("Lucy");
        //al.delete;  //these functionality doesn't works here
        //al.insert(2,"hi"); //these functionality doesn't works here
        //al.replace("",""); //these functionality doesn't works here
        Iterator<String> itr = al.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
    }
}
