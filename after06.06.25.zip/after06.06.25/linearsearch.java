//linear Search by giving array and key in program
class LinearSearchExample{
    public void linearSearch(int[] arr,int key){
        for(int i = 0;i<arr.length;i++){
            if(arr[i] == key){
                System.out.print("Key Found at");
                System.out.print(" "+i);
            }
        }
    }
}
public class linearsearch {
    public static void main(String[] args) {
        int[] a1 = {10,20,30,50,70,90};
        int key = 50;
        LinearSearchExample se = new LinearSearchExample();
        se.linearSearch(a1, key);
    } 
}