//create two hashset and compare it and print common elements
import java.util.*;
public class dtaco11 {
    public static void main(String[] args) {
        HashSet<String> set1 = new HashSet<String>();
        set1.add("Apple");
        set1.add("Banana");
        set1.add("Mango");
        set1.add("Orange");
        set1.add("Grapes");

        HashSet<String> set2 = new HashSet<String>();
        set2.add("Banana");
        set2.add("Pineapple");
        set2.add("Grapes");
        set2.add("Kiwi");
        set2.add("Mango");

        System.out.println("Set 1: " + set1);
        System.out.println("Set 2: " + set2);

        HashSet<String> common = new HashSet<String>(set1);
        common.retainAll(set2);

        System.out.println("Common elements: " + common);
    }
}
