//data collections queue
import java.util.*;
public class dtaco5 {
    public static void main(String[] args) {
        PriorityQueue<String> al = new PriorityQueue<String>();
        al.add("Alice");//adds data
        al.add("Daniel");
        al.add("Jones");
        al.add("Smith");
        al.remove("Jones");
        al.poll(); //removes top most element
        //al.pop();  //these functionality doesn't works here
        //al.delete; //these functionality doesn't works here
        //al.insert(2,"hi");  //these functionality doesn't works here
        //al.replace("","");  //these functionality doesn't works here
        System.out.println("head:"+al.element());
        System.out.println("head:"+al.peek());//gives top most element
        System.out.println("iterating the queue elements");
        }
    }