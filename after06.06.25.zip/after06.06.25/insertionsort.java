//insertion sort
public class insertionsort {
    public static void main(String[] args) {
        int[] arr1 = {5,3,4,1,2};
        for(int i = 0;i<arr1.length;i++){
            int key = arr1[i];
            int j = i-1;
            while(j>=0 && arr1[j]>key){
                arr1[j+1] = arr1[j];
                j--;
            }
            arr1[j+1]=key;
        }
        for(int i = 0;i<arr1.length;i++){
                System.out.print(arr1[i]+" ");
        }
    }
}