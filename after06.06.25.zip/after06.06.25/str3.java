// to convert the user input string1 to upper case and string2 to lower case using ASCII values
import java.util.*;
public class str3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        sc.close();
    }
    
}
