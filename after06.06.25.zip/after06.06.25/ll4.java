//to get length of the Linked list 
/*import java.util.*;

public class ll4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<Integer> list = new LinkedList<Integer>(); // Use LinkedList<Integer>
        list.add(10); // Use LinkedList.add()
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        list.add(60);
        System.out.println(list); // Print the list
        LinkedListLength lengthFinder = new LinkedListLength();
        int length = lengthFinder.getLengthIterative(getFirstNode(list));
        System.out.println("Length: " + length);
        sc.close();
    }

    // Helper method to get the first node of the LinkedList
    private static Node getFirstNode(LinkedList<Integer> list) {
        if (list.isEmpty()) {
            return null;
        }
        return new Node(list.getFirst()); // Assuming you want to create a Node from the first element
    }
}

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedListLength {
    public int getLengthIterative(Node head) {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }
}*/