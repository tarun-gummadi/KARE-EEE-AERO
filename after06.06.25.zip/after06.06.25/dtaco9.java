//create an array and get input from user and convert into hashset
import java.util.*;
public class dtaco9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size:");
        int arraysize = sc.nextInt();
        String[] arr19 = new String[arraysize];
        for (int i = 0; i < arraysize; i++) {
            System.out.print("Enter value " + (i + 1) + ": ");
            arr19[i] = sc.next();
        }
        sc.close(); 
        System.out.println("These are the values you entered:");
        for (int i = 0; i < arraysize; i++) {
            System.out.print(arr19[i] + " ");
        }System.out.println();
        HashSet<String> set = new HashSet<String>();
        for (int i = 0; i < arraysize; i++) {
            set.add(arr19[i]);
        }
        System.out.println("Unique elements...");
        System.out.println(set);
    }
}