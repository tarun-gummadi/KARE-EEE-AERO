//selection sort
import java.util.Scanner;
public class bubblesort {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements to add in the array");
        int n = sc.nextInt();
        int[] arr22 = new int[n];
        for(int i = 0;i<n;i++){
            System.out.println("Enter the value for "+i);
            arr22[i]= sc.nextInt();
        }
        //bubble sort
        for(int i = 0;i<arr22.length-1;i++){
            for(int j =0;j<arr22.length-1-i;j++){//if you're using j=i+1 put j<arr22.length-1
                if(arr22[j+1]>arr22[j]){//put < if you want array sorted in ascending order
                    int temp = arr22[j];
                    arr22[j]=arr22[j+1];
                    arr22[j+1]=temp;
                }
            }
        }
        //printing the sorted array
        System.out.println("Sorted Array");
        for(int i = 0;i<n;i++){
            System.out.print(arr22[i]+" ");
        }
        sc.close();
    }
}