//data collections deque
import java.util.*;
public class dtaco6 {
    public static void main(String[] args) {
        Deque<String> al = new ArrayDeque<String>();
        al.add("Lucy");//adds data
        al.add("Andrew"); //adds data
        al.add("Henery");
        al.remove("Henery");
        for(String str : al){
            System.out.println(str);
        }
        }
    }