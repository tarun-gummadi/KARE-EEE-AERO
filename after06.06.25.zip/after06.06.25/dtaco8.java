//Converting array to hashset and finding unique elements
//creating another set and copying from first set
//using different methods
import java.util.*;
public class dtaco8 {
    public static void main(String[] args) {
        ArrayList<String> arr19 = new ArrayList<String>();
        arr19.add("One");
        arr19.add("Two");
        arr19.add("Five");
        arr19.add("One");
        arr19.add("Three");
        arr19.add("Four");
        arr19.add("One");
        arr19.add("Five");
        arr19.add("One");
        arr19.add("Three");
        arr19.add("Four");
        HashSet<String> set = new HashSet<String>(arr19);
        set.remove("Four");
        System.out.println("After using remove method: ");
        System.out.println(set);
        HashSet<String> set1 = new HashSet<String>();
        set1.add("Ajay");
        set1.add("Gaurav");
        set.addAll(set1);
        System.out.println("Updated List");
        System.out.println(set);
        set.removeAll(set1);
        System.out.println("After remove all method");
        System.out.println(set);
        Iterator<String> itr = set.iterator();
        System.out.println("The Unique elements are....");
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
    }
    
}
