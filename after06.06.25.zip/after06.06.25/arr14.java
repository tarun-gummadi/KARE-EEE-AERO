//to print the first repeating element in an array
import java.util.*;
public class arr14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size : ");
        int arraysize = sc.nextInt();
        int[] arr15 = new int[arraysize];
        for (int i = 0; i < arraysize; i++) {
            System.out.print("Enter value " + (i + 1) + ": ");
            arr15[i] = sc.nextInt();
        }
        sc.close(); 
        System.out.println("These are the values you entered:");
        for (int i = 0; i < arraysize; i++) {
            System.out.print(arr15[i] + " ");
        }System.out.println();
        System.out.println("The First repeating element is:");
        for (int i=0;i<arr15.length;i++){
            int count = 0;
            for(int j=0;j<arr15.length;j++){
                if(arr15[i] == arr15[j]){
                count++;
            }
            }
            int seen = 0;
            for(int k = 0;k<i;k++){
                if(arr15[k]==arr15[i]){
                    seen = 1;
                    break;
                }
            }
            for(int s =0;s<arr15.length;s++){
                if(count > 1 && seen == 1){
                    System.out.println(arr15[i]+" for "+count);   
                    return;
                }
            }      
    }  
}
}