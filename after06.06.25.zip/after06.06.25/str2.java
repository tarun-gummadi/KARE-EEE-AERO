//to print how many vowels are there in a string
import java.util.*;
public class str2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String");
        String s1 = sc.nextLine();
        int count = 0;
        for(int k=0;k<s1.length();k++){
            char ch = s1.charAt(k);
            if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ){
                count++;
            }
        }
        System.out.println("The number of vowels in a String is"+" "+count);
        sc.close();

    }
}

//other way of implementation
/*String s1 = sc.nextLine();
        for(int i=0;i<s1.length();i++){
        int count = 0;
            if(s1.charAt(i)== 'a'|| s1.charAt(i) == 'e'|| s1.charAt(i) == 'i'|| s1.charAt(i) == 'o'|| s1.charAt(i) == 'u'|| s1.charAt(i) == 'A'|| s1.charAt(i) == 'E'|| s1.charAt(i) == 'I'|| s1.charAt(i) == 'O'|| s1.charAt(i) == 'U'){
            count++;
            }
        }
        System.out.println("The number of vowels in a String is"+" "+count); */