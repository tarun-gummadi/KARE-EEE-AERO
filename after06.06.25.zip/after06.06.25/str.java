//to print how many number of consonants are there in a string and also ignoring the spaces and characters
import java.util.*;
public class str {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the String");
        String s1 = sc.nextLine();
        int count = 0;
        for(int i=0;i<s1.length();i++){
            if(s1.charAt(i)!= 'a' && s1.charAt(i) != 'e'&& s1.charAt(i) != 'i'&& s1.charAt(i) != 'o'&& s1.charAt(i) != 'u'&& s1.charAt(i) != 'A'&& s1.charAt(i) != 'E'&& s1.charAt(i) != 'I'&& s1.charAt(i) != 'O'&& s1.charAt(i) != 'U' && s1.charAt(i)!=' ' && s1.charAt(i)!=',' && s1.charAt(i)!='\'' && s1.charAt(i)!='.'&& s1.charAt(i)!='!'&& s1.charAt(i)!='\"')
            {
                count++;
            }  
        }
        System.out.println("The number of consonants in a String is"+" "+count);
        sc.close();
    }
}
