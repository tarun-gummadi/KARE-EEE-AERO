// Matrix Addition
import java.util.Scanner;
public class mdarr11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of rows for Matrix: ");
        int r1 = sc.nextInt();
        System.out.print("Enter number of columns for Matrix: ");
        int c1 = sc.nextInt();
        int[][] mat1 = new int[r1][c1];
        System.out.println("Enter elements for Matrix 1:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                System.out.print("Element [" + i + "][" + j + "]: ");
                mat1[i][j] = sc.nextInt();
            }
        }
        int[][] mat2 = new int[r1][c1];
        System.out.println("Enter elements for Matrix 2:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                System.out.print("Element [" + i + "][" + j + "]: ");
                mat2[i][j] = sc.nextInt();
            }
        }
        int[][] result = new int[r1][c1];
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                result[i][j] = mat1[i][j] + mat2[i][j];
            }
        }
        System.out.println("Result of Matrix Addition:");
        for (int i = 0; i < r1; i++) {
            for (int j = 0; j < c1; j++) {
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }

        sc.close();
    }
}
