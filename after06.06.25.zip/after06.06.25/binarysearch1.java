//Binarysearch
import java.util.*;
public class binarysearch1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size: ");
        int a = sc.nextInt();
        int[] arr20 = new int[a];
        for(int i = 0; i < arr20.length; i++) {
            System.out.println("Enter value of the element " + i + ": ");
            arr20[i] = sc.nextInt();
        }
        Arrays.sort(arr20);
        System.out.println("Enter the value you need to search: ");
        int n = sc.nextInt();
        Binarysearch bs = new Binarysearch();
        bs.binsear(arr20, a, n);
        sc.close();
    }    
}
class Binarysearch {
    public void binsear(int arr20[], int a, int n) {
        int low = 0;
        int high = a - 1;
        boolean found = false;
        while(low <= high) {
            int mid = (low + high) / 2;
            if(arr20[mid] == n) {
                System.out.println("The element found at index " + mid);
                found = true;
                break;
            } else if(arr20[mid] < n) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        if(!found) {
            System.out.println("We didn't find that value...");
        }
    }
}