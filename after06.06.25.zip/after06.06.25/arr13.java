//to print number of time a each number occured in an array
import java.util.*;
public class arr13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the array size (between 1 to 25): ");
        int arraysize = sc.nextInt();
        if (arraysize <= 0 || arraysize > 25) {
            System.out.println("Enter a value in between 1 to 25");
            sc.close();
            return;
        }
        int[] arr15 = new int[arraysize];
        boolean[] counted = new boolean[arraysize];
        for (int i = 0; i < arraysize; i++) {
            System.out.print("Enter value " + (i + 1) + ": ");
            arr15[i] = sc.nextInt();
        }
        System.out.println("These are the values you entered:");
        for (int i = 0; i < arraysize; i++) {
            System.out.print(arr15[i] + " ");
        }System.out.println();
        System.out.println("Occurence of each number:");
        for (int i = 0; i < arraysize; i++) {
            if (counted[i]==true) {
                continue;
            }
            int count = 1;
            for (int j = i + 1; j < arraysize; j++) {
                if (arr15[i] == arr15[j]) {
                    count++;
                    counted[j] = true; 
                }
            }
            System.out.println(arr15[i] +" occured "+ count);
        }
        sc.close();
    }
}