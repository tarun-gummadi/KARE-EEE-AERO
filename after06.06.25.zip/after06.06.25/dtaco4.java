//data collections stack
import java.util.*;
public class dtaco4 {
    public static void main(String[] args) {
        Stack<String> al = new Stack<String>();
        al.push("CPU");//adds data
        al.push("Monitor");
        al.push("Mouse");
        al.push("Key board");
        al.push("Printer");
        al.pop();//used to remove last element
        //al.delete;   //these functionality doesn't works here
        //al.insert(2,"hi");  //these functionality doesn't works here
        //al.replace("","");  //these functionality doesn't works here
        Iterator<String> itr = al.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
    }
}
