/*Write a java program to reverse the string without using any string library functions */
import java.util.*;
public class str4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
            System.out.println("Enter the String: ");
            String str1 = sc.nextLine();
            for(int i=str1.length()-1;i>=0;i--){
                System.out.print(str1.charAt(i));
            }
            sc.close();
    }   
}