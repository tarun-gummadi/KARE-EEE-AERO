//placement question
/*IPL sum*/
import java.util.Scanner;
public class TicketChecker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Ticket Code: ");
        String str1 = sc.nextLine();
        int count = 0;
        int count1 = 0;
        for(int i = 0;i<str1.length();i+=2){
            if(str1.charAt(0)==str1.charAt(i)){
                count++;
            }
        }
        for(int i = 1;i<str1.length();i+=2){
            if(str1.charAt(1)==str1.charAt(i)){
                count1++;
            }
        }
        if(count+count1 == str1.length()){
            System.out.println("YES");
        }else{
            System.out.println("NO");
        }
        sc.close();
    }
}