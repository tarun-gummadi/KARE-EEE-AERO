//printing a String by getting string from user
import java.lang.String;
import java.util.Scanner;
public class str1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string:");
        String str1 = sc.nextLine();
        System.out.println(str1);
        sc.close();
    }
    
}
