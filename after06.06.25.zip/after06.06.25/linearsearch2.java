//linear search by getting input from user
import java.util.Scanner;
class LinearSearchExam{
    public void linearSearch(int[] arr,int key){
        for(int i = 0;i<arr.length;i++){
            if(arr[i] == key){
                System.out.println();
                System.out.print("Key Found at");
                System.out.print(" "+i);
            }
        }
    }
}
public class linearsearch2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter array size");
        int n = sc.nextInt();
        int[] a1 = new int[n];
        for(int i = 0;i<n;i++){
            System.out.println("Enter the array values");
            a1[i] = sc.nextInt();
        }
        System.out.println("The values in the array is...");
        for(int i = 0;i<n;i++){
            System.out.print(a1[i]+" ");
        }System.out.println();
        System.out.println("Enter value you need to search for..");
        int key = sc.nextInt();
        LinearSearchExam se = new LinearSearchExam();
        se.linearSearch(a1, key);
        sc.close();
        
    }
}